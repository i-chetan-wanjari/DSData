mcar<-read.csv("D:\\training\\marsian\\slidesforyournextclassesonrmachinelearning\\009B_Simple_Lnr_Rgrsn_Assignment\\cars.csv")
nrow(mcar)
ncol(mcar)

# PIE DEMO
cytblslice<-table(mcar$Cylinders)
pie(cytblslice)
lbls<-c('3cy','4cy','5cy','6cy','8cy')
pie(cytblslice,labels = lbls)
pie(cytblslice,labels = lbls,main='table of cylinders')
pie(cytblslice,labels = lbls,main='table of cylinders',col = rainbow(length(lbls)))
library(plotrix)
pie3D(cytblslice,labels = lbls,main='table of cylinders',explode = 0.2)

pct <- round(cytblslice/sum(cytblslice)*100)
lbls <- paste(lbls, pct) # add percents to labels
lbls <- paste(lbls,"%",sep="") # ad % to labels
pie3D(cytblslice,labels = lbls,main='table of cylinders',explode = 0.1,radius = 0.5)


# BAR DEMO
# Simple Bar Plot 
counts <- table(mtcars$gear)
barplot(counts, main="Car Distribution",xlab="Number of Gears")
par(las=2) # make label text perpendicular to axis
barplot(counts, main="Car Distribution", horiz=TRUE, names.arg=c("3 Gears", "4 Gears", "5 Gears"))


# Grouped Bar Plot
counts <- table(mtcars$vs, mtcars$gear)
barplot(counts, main="Car Distribution by Gears and VS",  xlab="Number of Gears", col=c("darkblue","red"),
        legend = c("gear","VS"), beside=TRUE, ylab= "gear and vs",axis.lty=1) # removing beside will stack variables.


# Histograms 
hist(mcar$MPG)
hist(mcar$MPG, breaks = 5)
hist(mcar$MPG, breaks = 5, col = rainbow(1))
hist(mcar$MPG, breaks = 5, col = 'cyan',xlab = "MILES PER GALLON")
plot(density(mcar$MPG),col = 'red')
plot(density(mcar$MPG, bw = 1),col = 'red')


#Simple Scatterplot

plot(mcar$Weight, mcar$MPG, main="Scatterplot Example", 
     xlab="Car Weight ", ylab="Miles Per Gallon ", pch=3)

# Add fit lines
abline(lm(mcar$MPG~mcar$Weight), col="red") # regression line (y~x) 


boxplot(mcar$MPG)
boxplot(mcar$MPG,horizontal = TRUE)

# Boxplot of MPG by Car Cylinders 
boxplot(mcar$MPG~mcar$Cylinders,data=mcar, main="Car Milage Data", xlab="Number of Cylinders", 
        ylab="Miles Per Gallon", col = rainbow(5))


# Violin Plots ### NOTE MTCARS IS BEING USED, not macars.
library(vioplot)
x1 <- mtcars$mpg[mtcars$cyl==4]
x2 <- mtcars$mpg[mtcars$cyl==6]
x3 <- mtcars$mpg[mtcars$cyl==8]
vioplot(x1, x2, x3, names=c("4 cyl", "6 cyl", "8 cyl"), 
        col="gold")
title("Violin Plots of Miles Per Gallon")


plot(mcar$MPG, mcar$Horsepower)
summary(mcar$MPG)
carf<-mcar[mcar$Cylinders==4,]
carsi<-mcar[mcar$Cylinders==6,]
carei<-mcar[mcar$Cylinders==8,]
mean(carf$Weight)
y<-mcar$Displacement
x<-mcar$Weight
cor(x,y)
mcar.lm = lm(y~x)
summary(mcar.lm)
plot(y,x)
pairs(mcar)
df<-data.frame(cyl=mcar$Cylinders,wt=mcar$Weight,hp=mcar$Horsepower)
mdf<-cor(df)

pdf("d:\\myplot.pdf")
corrplot(mdf, method = "circle")
dev.off()
