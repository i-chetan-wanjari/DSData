cereal = read.csv("D:\\training\\marsian\\slidesforyournextclassesonrmachinelearning\\009B_Simple_Lnr_Rgrsn_Assignment\\cereal.csv")
library(Amelia)
library(corrplot)
missmap(cereal) # Requies 
summary(cereal)
cereal<-na.omit(cereal)
cor(cereal$calories,cereal$rating)
mean(cereal$calories)
sd(cereal$calories)
crmodel.lm = lm(cereal$rating~cereal$calories)
summary(crmodel.lm)
predict.lm(crmodel.lm,newdata=data.frame(calories=c(15)))
plot(density(cereal$sodium))
clmdf<-data.frame(cal=cereal$calories,cups=cereal$cups,rating=cereal$rating)
M<-cor(clmdf)
corrplot(M)


