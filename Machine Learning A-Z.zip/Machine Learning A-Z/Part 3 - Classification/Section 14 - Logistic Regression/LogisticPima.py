# -*- coding: utf-8 -*-
"""
Created on Mon Feb 11 00:02:03 2019

@author: chetan
"""

#LOGISTIC REGRESSION IN PYTHON
#------------------LOGISTIC REGRESSION---------------------------------------------------------------
# Import library pandas
import pandas as pd
# Read the file using pandas
csv_file='C:/Users/vishwanathan.k/Desktop/pima-indians-diabetes.csv'
data=pd.read_csv(csv_file, header=None, sep = ',')
# Summary Statistics of the data
data.describe()
#---------------------------------------------------------------------------------------------------
# Top 5 rows of the data
data.head()
#---------------------------------------------------------------------------------------------------
# Dimention of the data
data.shape
#----------------------------------------------------------------------------------------------------
import matplotlib.pyplot as plt 
%matplotlib inline
data.hist()
plt.show()
#----------------------------------------------------------------------------------------------------
# Separating the predictors and targets from the data
x = data.iloc[:,:-1]
y = data.iloc[:, -1]
print(x.head())
print(y.head())
#----------------------------------------------------------------------------------------------------
# Build the Model
from sklearn import metrics
import statsmodels.api as sm
#from sklearn.linear_model import LogisticRegression
model = sm.Logit(y_train, x_train)
result = model.fit()
#----------------------------------------------------------------------------------------------------
#Print Summary
result.summary()
#---------------------------------------------------------------------------------------------------
#Print Confidence Intervals
result.conf_int()
#----------------------------------------------------------------------------------------------------
#Print Odds Ratio
import numpy as np
np.exp(result.params)
#----------------------------------------------------------------------------------------------------
# odds ratios and 95% CI
params = result.params
conf = result.conf_int()
conf['OR'] = params
conf.columns = ['2.5%', '97.5%', 'OR']
np.exp(conf)
#----------------------------------------------------------------------------------------------------
import matplotlib.pyplot as plt 
%matplotlib inline
probs = result.predict(x_test)
plt.hist(probs) 
plt.show()
print(probs)
#----------------------------------------------------------------------------------------------------
# use 0.5 cutoff for predicting 'default' 
expected =y_test
predicted = np.where(probs > 0.5, 1, 0) 
from nltk import ConfusionMatrix 
print(ConfusionMatrix(list(expected), list(predicted)))
#----------------------------------------------------------------------------------------------------
# check accuracy, sensitivity, specificity 
acc = metrics.accuracy_score(expected, predicted) 
acc
#----------------------------------------------------------------------------------------------------
# sensitivity:
sens = metrics.recall_score(expected, predicted)
sens
#----------------------------------------------------------------------------------------------------
#Specificity
spec = metrics.precision_score(expected, predicted)
spec
#----------------------------------------------------------------------------------------------------
# calculate AUC 
auc = metrics.roc_auc_score(expected, probs)
auc
#----------------------------------------------------------------------------------------------------
#ROC CURVES and AUC 
# plot ROC curve 
fpr, tpr, thresholds = metrics.roc_curve(expected, probs) 
plt.plot(fpr, tpr,color='red', label='ROC curve (area = %0.2f)'% auc) 
#plt.xlim([0.0, 1.0]) 
#plt.ylim([0.0, 1.0]) 
plt.plot([0, 1], [0, 1], color='navy', linestyle='--')
plt.xlabel('False Positive Rate') 
plt.ylabel('True Positive Rate)') 
plt.title('Receiver operating characteristic example')
plt.legend(loc="lower right")
plt.show()
#----------------------------------------------------------------------------------------------------
