# -*- coding: utf-8 -*-
"""
Created on Sun Feb 10 23:56:12 2019

@author: chetan
"""

#NAÏVE BAYES IN PYTHON
#------------------NAIVE BAYES CLASSIFIER---------------------------------------------------
# Import library pandas
import pandas as pd
# Read the file using pandas
csv_file='C:/Users/vishwanathan.k/Desktop/pima-indians-diabetes.csv'
data=pd.read_csv(csv_file, header=None, sep = ',')
# Summary Statistics of the data
print(data.describe())
# Top 5 rows of the data
print(data.head())
# Dimention of the data
print(data.shape)
#----------------------------------------------------------------------------------------------------# Separating the predictors and targets from the data
x = data.iloc[:,:-1]
y = data.iloc[:, -1]
print(x.head())
print(y.head())
#----------------------------------------------------------------------------------------------------# Splitting the data into training and test data
from sklearn.cross_validation import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.25, random_state=1)
#----------------------------------------------------------------------------------------------------
# Build the Model
from sklearn import metrics
from sklearn.naive_bayes import GaussianNB
model = GaussianNB()
model.fit(x_train, y_train)
print(model)
#----------------------------------------------------------------------------------------------------# Plotting Histogram
import matplotlib.pyplot as plt 
%matplotlib inline
probs = model.predict_proba(x_test)[:, 1] 
plt.hist(probs) 
plt.show()
#----------------------------------------------------------------------------------------------------from nltk import ConfusionMatrix 
expected =y_test
predicted = model.predict(x_test)
print (ConfusionMatrix(list(expected), list(predicted)))
#----------------------------------------------------------------------------------------------------# check accuracy, sensitivity, specificity 
acc = metrics.accuracy_score(expected, predicted) 
print(acc)
#----------------------------------------------------------------------------------------------------# sensitivity:
sens = metrics.recall_score(expected, predicted)
print(sens)
#----------------------------------------------------------------------------------------------------#Specificity
spec = metrics.precision_score(expected, predicted)
print(spec)
#----------------------------------------------------------------------------------------------------
# calculate AUC 
auc = metrics.roc_auc_score(expected, probs)
print (auc)
#----------------------------------------------------------------------------------------------------#ROC CURVES and AUC 
# plot ROC curve 
fpr, tpr, thresholds = metrics.roc_curve(expected, probs) 
plt.plot(fpr, tpr,color='red', label='ROC curve (area = %0.2f)'% auc) 
#plt.xlim([0.0, 1.0]) 
#plt.ylim([0.0, 1.0]) 
plt.plot([0, 1], [0, 1], color='navy', linestyle='--')
plt.xlabel('False Positive Rate') 
plt.ylabel('True Positive Rate)') 
plt.title('Receiver operating characteristic example')
plt.legend(loc="lower right")
plt.show()
#----------------------------------------------------------------------------------------------------
