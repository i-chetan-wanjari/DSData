#--------AirPassengers-------------------
data("AirPassengers")
class(AirPassengers)
str(AirPassengers)
View(AirPassengers)


start(AirPassengers)
head(AirPassengers)

end(AirPassengers)
tail(AirPassengers)

#The cycle of this time series is 12 months in a year 
frequency(AirPassengers)

summary(AirPassengers)

#This will plot the time series
ts.plot(AirPassengers)


#This will also fit in the line
abline(reg <- lm(AirPassengers ~ time(AirPassengers)),col=2)

cycle(AirPassengers)


decompose(AirPassengers)

plot(decompose(AirPassengers))

#This will aggregate the cycle and display a year on year trend

plot(aggregate(AirPassengers,FUN=mean))

boxplot(AirPassengers ~ cycle(AirPassengers))

acf(AirPassengers)


#------------------------------NyBirths----------
births<-read.csv("births.csv")
births
str(births)
plot.ts(births)
getwd()

birthstimeseries<- ts(births,frequency = 12,start=c(1946,1))


birthstimeseries
class(birthstimeseries)
plot.ts(birthstimeseries)

#birthtimeseriescomponent
btsc<-decompose(birthstimeseries)
plot(btsc)

names(btsc)

btssesonallyadjusted<- birthstimeseries-btsc$seasonal
plot(btssesonallyadjusted)#seasonal component removed

birthforcasts<- HoltWinters(btssesonallyadjusted,beta = FALSE,gamma = FALSE)
#
birthforcasts
names(birthforcasts)
bf<-birthforcasts$fitted
bf
plot(birthforcasts,col="blue")


#library(forecasts)

forecast:::forecast.HoltWinters(birthforcasts,h=8)
birthforcasts2<-forecast:::forecast.HoltWinters(birthforcasts,h=12)
birthforcasts2
plot(birthforcasts2)
names(birthforcasts2)

birthforcasts2$residuals
#residual means
plot(birthforcasts2$residuals)
hist(birthforcasts2$residuals)
plot(density(birthforcasts2$residuals,na.rm = T))
Box.test(birthforcasts2$residuals,lag=20,type = "Ljung-Box")
#lag=20 means checking for the for last 20 observations 
#there is auto corelation in this assumtion hence rejecting the null hypothesis as pvalue<a
#hence is considered as there should be no auto corelation in the box test