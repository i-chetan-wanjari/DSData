#Random Forest
library(MASS)
data("birthwt")
str(birthwt)
data$low <- as.factor(data$low)
table(data$NSP)


#Data Partition
set.seed(123)
int<- sample(2,nrow(data),replace=T,prob=c(0.7,0.3))
train<- data[ind==1,]
test<- data[ind==2,]
table(train$NSP)

#radom Forest
library(randomForest)
set.seed(222)
rf<- randomForest(NSP ~.,data=train,
                  ntree=300,
                  mtry=8,
                  importance=TRUE,
                  proximity=TRUE)
print(rf)
attributes(rf)

#